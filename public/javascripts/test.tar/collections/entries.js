window.Entries = Backbone.Collection.extend({
  model: Entry
});
